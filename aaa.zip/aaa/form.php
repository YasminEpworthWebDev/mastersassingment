<?php include('server.php')  ?>
<!DOCTYPE html>
<html>
<head>
    <title>Subscribe</title>
</head>
<body>

    <div class="container">

        <div class="header">

            <h2>Subscribe</h2>

        </div>
        <form action="form.php" method="post">

            <div>
                <label>First Name</label>
                <input type="text" name="FirstName" required>

            </div>

            <div>
                <label>Last Name</label>
                <input type="text" name="LastName" required>

            </div>    

            <div>
                <label>Email</label>
                <input type="email" name="Email" required>

            </div>


        <button type="submit" name="sub_user"> Submit </button>



        </form>
    </div>





</body>
</html>