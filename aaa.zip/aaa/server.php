<?php 

session_start();

//initialising variables

$FirstName = "localhost";
$LastName ="root";
$email = "";

$db_name ="user";

$errors = array();
//connect to db

$con = mysqli_connect("localhost","root","", "kkk");
	if (!$con) {
		die ("Failed");
	}
?>