<!DOCTYPE html>
<html>
<head>
    <title>Subscribe</title>
</head>
<body>

    <div class="container">
        <div class="header">

            <h2>Subscribe</h2>
        </div>
        <form action="server.php" method="POST">
            
                <label>First Name</label>
                <input type="text" name="firstname" placeholder="please input your first name">
            

            
                <label>Last Name</label>
                <input type="text" name="lastname" required>
              

            
                <label>Email</label>
                <input type="email" name="email" required>
        


            <input type='submit', value='register'>



        </form>
    </div>
    

</body>
</html>