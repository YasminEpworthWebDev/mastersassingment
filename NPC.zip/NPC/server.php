<?php 

//initialising variables

$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$email = $_POST['email'];



$con = mysqli_connect("localhost","root","", "kkk");
	if (!$con) {
		die ("Failed");
	}

	$sql = "INSERT INTO `user`(`firstName`, `lastName`, `email`) VALUES ('$firstname', '$lastname', '$email')";
if ($con->query($sql)) 

	print ("New record created successfully");


?>