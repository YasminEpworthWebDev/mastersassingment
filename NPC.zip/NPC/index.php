<!doctype html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Noah's Pet Clinic</title>
<link href="style.css" rel="stylesheet" type="text/css">
<!--The following script tag downloads a font from the Adobe Edge Web Fonts server for use within the web page. We recommend that you do not modify it.-->
<script>var __adobewebfontsappname__="dreamweaver"</script>
<script src="http://use.edgefonts.net/source-sans-pro:n2:default.js" type="text/javascript"></script>
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<!-- Main Container -->
<div class="container"> 
  <!-- Navigation -->
  <header> <a href=""><img src="images/logo2.png">
    <h4 class="logo"></h4>
    </a>
    <nav>
      <ul>
        <li><a href="index.php">HOME</a></li>
        <li><a href="gallery.php">GALLERY</a></li>
        <li> <a href="subscribe.php">SUBCRIBE</a></li>
      </ul>
    </nav>
  </header>
  <!-- Hero Section -->
  <section class="hero" id="hero">
    <h2 class="hero_header">&nbsp;</h2>
    <h2 class="hero_header">&nbsp;</h2>
    <h2 class="hero_header">&nbsp;</h2>
    <h2 class="hero_header">&nbsp;</h2>
    <h2 class="hero_header">NOAH'S <span class="light">PET CLINIC</span></h2>
<p class="tagline">Adding care to your animals</p>
  </section>
	
  <!-- About Section -->
  <section class="about" id="about">
    <h2>Grooming</h2>
    <p class="text_column">At Noah’s Pet Clinic, we provide a variety of services and products needed to receive the best care for your pets. As we specialise in dog care, we provide on-site grooming for your curious canines and grooming for cats and rabbits. Our team are qualified in handling all pets, no matter the size or age.</p>
	<h3>Veterinarian Medicines</h3>
    <p class="text_column">We have the best veterinarian medicines distillery within Manchester as we source only the best for your pets. Our patients have a wide variety of issues that we treat which means we have universal care for your pets. All of our doctors and nurses are qualified and determined to keep your pet fit and healthy. </p>
	<h4>X-Ray</h4>
    <p class="text_column">X-Ray (or radiography) is a diagnostic procedure which allows us to see inside your pet’s body to assess their bones and organs for any issues or diseases. X-ray is a commonly used imaging technique which helps provide vets with more information to help us learn about what is going on inside a dog, cat or rabbit.</p>
  </section>
	

	
  <!-- Stats Gallery Section
  <div class="gallery">
    <div class="thumbnail1">
      <h1><img src="images/grooming.jpg" alt="dog grooming" height="170" width="250"></h1>
    </div>
    <div class="thumbnail2">
      <h1 class="stats"><img src="images/medicines.jpg" alt="medicines" height="170" width="250"></h1>
    </div>
    <div class="thumbnail3">
      <h1 class="stats"><img src="images/xray.jpg" alt="xray" height="170" width="250"></h1>
    </div>
  </div>


  <!-- Parallax Section -->
  <section class="banner">
    <h2 class="parallax">Did you know?</h2>
    <p class="parallax_description">Dogs are the most popular animal to show up on their veterinary exam table, as 46.3 million households in the United States own a dog!</p>
  </section>
  <!-- More Info Section -->
  <footer>
    <article class="footer_column">
      <h3>ABOUT</h3>
      <img src="images/about.jpg" alt="" width="400" height="250" class="cards"/>
      <p>Noah’s pet clinic (NPC) is a veterinary office in rural Manchester which is a specialised dog clinic but also has other types of pets. A family run veterinary practice to look after all of your pets, no matter the size or age. We are a dedicated team of nurses and doctors who want the best care for your pets.</p>
    </article>
    <article class="footer_column">
      <h3>LOCATION</h3>
      <img src="images/manchester.jpg" alt="" width="400" height="200" class="cards"/>
      <p>Our clinic is located in the outskirts of Manchester. Please call our clinic if you need any help with directions to us. Our clinic is based in Whilmslow which is a 30 minute journey from the city center of Manchester. </p>
    </article>
  </footer>
  <!-- Footer Section -->
  <section class="footer_banner" id="contact">
    <h2 class="hidden">Footer Banner Section </h2>
    <p class="hero_header">FOR THE LATEST NEWS &amp; UPDATES</p>
    <div class="button">Follow our social media accounts!</div>
  </section>
  <!-- Copyrights Section -->
  <div class="copyright">&copy;2020- <strong>Yasmin Epworth</strong></div>
</div>
<!-- Main Container Ends -->
</body>
</html>
