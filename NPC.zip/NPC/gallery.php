<!doctype html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Gallery</title>
<link href="style.css" rel="stylesheet" type="text/css">
<!--The following script tag downloads a font from the Adobe Edge Web Fonts server for use within the web page. We recommend that you do not modify it.-->
<script>var __adobewebfontsappname__="dreamweaver"</script>
<script src="http://use.edgefonts.net/source-sans-pro:n2:default.js" type="text/javascript"></script>
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<!-- Main Container -->
<div class="container"> 
  <!-- Navigation -->
  <header> <a href="">
    </a>
    <nav>
      <ul>
        <li><a href="index.php">HOME</a></li>
        <li><a href="gallery.php">GALLERY</a></li>
        <li> <a href="subscribe.php">SUBCRIBE</a></li>
      </ul>
    </nav>
  </header>
  <!-- Hero Section -->
  <section class="hero" id="hero">
    <h2 class="hero_header">NOAH'S <span class="light">PET CLINIC</span></h2>
    <p class="tagline">Adding care to your animals</p>
  </section>
	
	<div class="wrap">
<div class="tile"> 
  <img src="images/grooming3.jpg" alt="">
  <div class="text">
  <h1>Dog Grooming</h1>
  <h2 class="animate-text">What type of grooming do we provide?</h2>
  <p class="animate-text">Nail clippings, hair trimming and wash and blow dry. If you have any specific requirements please ask one of our groomers, we are welcome to try anything!</p>
<div class="dots">
    <span></span>
    <span></span>
    <span></span>
  </div>
  </div>
 </div>


<div class="tile"> 
  <img src="images/medicines2.jpg" alt="">
  <div class="text">
  <h1>Vetinerary Medicines</h1>
  <h2 class="animate-text">What type of medicines do we provide?</h2>
  <p class="animate-text">We provide the best care for our patients through providing them with top quality medicines.</p>
<div class="dots">
    <span></span>
    <span></span>
    <span></span>
  </div>
  </div>
 </div>
  
  <div class="tile"> 
  <img src="images/xray2.jpg" alt="">
  <div class="text">
  <h1>X-Ray</h1>
  <h2 class="animate-text">What type of X-Ray facilities do we provide?</h2>
  <p class="animate-text">We provide only the best equipment at our facility. From Static Generators to Dental Imaging.</p>
<div class="dots">
    <span></span>
    <span></span>
    <span></span>
  </div>
  </div>
 </div>
</div>
  
  
</div>

	
	
	

	
	<br><br><br><br><br><br><br><br><br><br><br><br><br><br>
  <!-- Footer Section -->
  <section class="footer_banner" id="contact">
    <h2 class="hidden">Footer Banner Section </h2>
    <p class="hero_header">FOR THE LATEST NEWS &amp; UPDATES</p>
    <div class="button">Follow our social media accounts</div>
  </section>
  <!-- Copyrights Section -->
  <div class="copyright">&copy;2020- <strong>Yasmin Epworth</strong></div>
<!-- Main Container Ends -->
</body>
</html>
