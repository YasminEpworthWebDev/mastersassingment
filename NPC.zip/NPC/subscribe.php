<!doctype html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Subscribe</title>
<link href="style.css" rel="stylesheet" type="text/css">
<!--The following script tag downloads a font from the Adobe Edge Web Fonts server for use within the web page. We recommend that you do not modify it.-->
<script>var __adobewebfontsappname__="dreamweaver"</script>
<script src="http://use.edgefonts.net/source-sans-pro:n2:default.js" type="text/javascript"></script>
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<!-- Main Container -->
<div class="container"> 
  <!-- Navigation -->
  <header> <a href="">
    </a>
    <nav>
      <ul>
        <li><a href="index.php">HOME</a></li>
        <li><a href="gallery.php">GALLERY</a></li>
        <li> <a href="subscribe.php">SUBCRIBE</a></li>
      </ul>
    </nav>
  </header>
  <!-- Hero Section -->
  <section class="hero" id="hero">
    <h2 class="hero_header">NOAH'S <span class="light">PET CLINIC</span></h2>
    <p class="tagline">Adding care to your animals</p>
  </section>

	
	<!--PHp Form Section -->
	<div class="formcontainer">
        <div class="form">
		<p>To hear more about Noah's Pet Clinic, subscribe below to recieve our weekly newsletter!</p>
            <h2>Subscribe</h2>
        </div>
        <form action="server.php" method="POST">
            
                <label>First Name</label>
                <input type="text" name="firstname" placeholder="please input your first name">
            

            
                <label>Last Name</label>
                <input type="text" name="lastname" placeholder="please input your last name">
              

            
                <label>Email</label>
                <input type="email" name="email" placeholder="please input your email">
        


            <input type="submit" value="register">
        </form>
    </div>
    
	
	
<!-- Footer Section -->
  <section class="footer_banner" id="contact">
    <h2 class="hidden">Footer Banner Section </h2>
    <p class="hero_header">FOR THE LATEST NEWS &amp; UPDATES</p>
    <div class="button">Follow our social media accounts</div>
  </section>
  <!-- Copyrights Section -->
  <div class="copyright">&copy;2020- <strong>Yasmin Epworth</strong></div>
</div>
<!-- Main Container Ends -->
</body>
</html>

